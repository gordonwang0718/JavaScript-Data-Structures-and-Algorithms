// Template literals
var book = {
    name: 'Learning JavaScript DataStructures and Algorithms'
};

console.log(`You are reading ${book.name}.,
    and this is a new line`);