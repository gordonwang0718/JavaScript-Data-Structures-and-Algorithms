If you are using Mozilla Firefox in order to run the code files, make sure you download and install Firebug plugin.

You can use either of the environment mentioned in Chapter 1, in order to run the code files.

Chapter 3 : You will find Tower of Hanoi code file in the chapter03 folder.

Chapter 8 : You will find Red black tree code file in the chapter08 folder.

Chapter 11 : You will find Knapsack Recursive, Recursive Longest Common Subsequence Recursive,                           Matrix Chain Multiplication Recursive in the chapter11 folder.

Chapter 12 : Big O chart is plotted using javascript, you can find the code file inside the big0chart folder              under chapter12. 

